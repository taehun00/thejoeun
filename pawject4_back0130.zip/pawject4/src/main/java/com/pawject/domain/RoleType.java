package com.pawject.domain;

public enum RoleType {
    ROLE_MEMBER,
    ROLE_ADMIN
}