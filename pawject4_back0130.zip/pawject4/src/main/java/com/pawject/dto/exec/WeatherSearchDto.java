package com.pawject.dto.exec;

import lombok.Data;

@Data
//@Getter @Setter @ToString
//@AllArgsConstructor
//@NoArgsConstructor

public class WeatherSearchDto {
	private Integer 	       wid;	 //WID
	private String         weather;	 //WEATHER
	private String  weathercontent;	 //WEATHERCONTENT
}