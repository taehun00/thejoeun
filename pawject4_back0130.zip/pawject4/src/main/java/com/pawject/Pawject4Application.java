package com.pawject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pawject4Application {

	public static void main(String[] args) {
		SpringApplication.run(Pawject4Application.class, args);
	}

}

// http://localhost:8484/swagger-ui/index.html